# Palestra

Prenotazione dei laboratori, Node.js senza dipendenze.

- Test: `npm test`
- Il codice è in `src/`, i test in `test/`.
