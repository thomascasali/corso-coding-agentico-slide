# Palestra

App Node.js per prenotare i laboratori della scuola.

- I dati stanno in `dati/prenotazioni.json`.
- Si usa dalla riga di comando: `node cli.js elenco`.
- Scrivi il codice in italiano.
