# Palestra: prenotazione dei laboratori

Piccola applicazione del corso "Coding agentico". Serve a provare ogni tecnica del corso su un
codice vero ma piccolo. I dati sono **inventati** (laboratori, docenti, classi e prenotazioni non
esistono; le email finiscono tutte in `@demo.invalid`). Non c'è nessun collegamento a sistemi della
scuola e non serve la rete.

Requisiti: Node.js 20 o più recente. Nessuna dipendenza da installare.

## Come si avvia

```
node cli.js laboratori
node cli.js elenco
node cli.js elenco --data 2026-11-12
node cli.js elenco --docente d01 --tutte
node cli.js prenota --lab LAB-INF1 --docente d01 --classe 3A-INF --data 2027-09-21 --inizio 09:00 --fine 11:00
```

Le date dell'esempio devono essere future e non di chiusura: se la tua è passata, scegline una successiva. `prenota` scrive in `dati/dati.json`. Per riportare i dati allo stato iniziale: `git restore dati/dati.json`.

Server con una pagina web (facoltativo): `node server.js`, poi apri http://127.0.0.1:3000 .
Ascolta solo sul tuo PC.

## Come si testa

```
node --test
```

Il test runner è quello integrato in Node. I test non toccano `dati/dati.json`: lavorano su una copia.

## Com'è fatta

```
cli.js              riga di comando
server.js           server HTTP minimo (facoltativo)
public/index.html   la pagina del server
src/logica.js       le regole di prenotazione
src/archivio.js     lettura e scrittura del file JSON
src/formato.js      come si stampano le righe
dati/dati.json      laboratori, docenti, classi, prenotazioni (inventati)
test/               i test
docs/               l'idea della dashboard (altri documenti compaiono negli esercizi)
```

## Le regole, in breve

- I laboratori sono aperti dal lunedì al venerdì, dalle 08:00 alle 18:00, tranne nei giorni di chiusura
  elencati nei dati.
- Non si prenota nel passato.
- La classe deve starci nel laboratorio.
- Due prenotazioni dello stesso laboratorio non si possono sovrapporre.
- Una prenotazione annullata non conta più.

I dettagli sono nel codice di `src/logica.js` e nei test.

## Punti di partenza degli esercizi

Il repository del PC ha il ramo `main`, che è la base della palestra, e dei tag, uno per ogni esercizio:
`git tag` li elenca. Ogni tag parte dallo stato che l'app dovrebbe avere se gli esercizi precedenti fossero
andati bene. Se un esercizio è venuto male, si riparte da uno stato noto senza perdere il lavoro:

```
git status                       # controlla di non avere modifiche da salvare
git switch -c lavoro-a6 partenza-a6
```

(`lavoro-a6` è un nome a scelta.) Per tornare alla base: `git switch main`: è la base, uguale per tutti.
