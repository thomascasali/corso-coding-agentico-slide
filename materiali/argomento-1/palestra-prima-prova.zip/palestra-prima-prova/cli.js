#!/usr/bin/env node
'use strict';
// Riga di comando della palestra.
//
//   node cli.js laboratori
//   node cli.js elenco [--data AAAA-MM-GG] [--docente d01] [--tutte]
//   node cli.js prenota --lab LAB-INF1 --docente d01 --classe 3A-INF \
//                       --data 2026-12-10 --inizio 09:00 --fine 11:00
//
// Uscita: 0 = ok, 1 = regola non rispettata, 2 = uso sbagliato.
// Variabili per le prove: PALESTRA_DATI (file dei dati), PALESTRA_ADESSO (data e ora fissate).
const { parseArgs } = require('node:util');
const archivio = require('./src/archivio');
const logica = require('./src/logica');
const { riga } = require('./src/formato');

const OPZIONI = {
  elenco: { data: { type: 'string' }, docente: { type: 'string' }, tutte: { type: 'boolean' } },
  laboratori: {},
  prenota: {
    lab: { type: 'string' },
    docente: { type: 'string' },
    classe: { type: 'string' },
    data: { type: 'string' },
    inizio: { type: 'string' },
    fine: { type: 'string' },
  },
};

const USO = `Uso:
  node cli.js laboratori
  node cli.js elenco [--data AAAA-MM-GG] [--docente d01] [--tutte]
  node cli.js prenota --lab ID --docente ID --classe ID --data AAAA-MM-GG --inizio HH:MM --fine HH:MM`;

function adessoDaAmbiente(env) {
  return env.PALESTRA_ADESSO ? new Date(env.PALESTRA_ADESSO) : new Date();
}

// Esegue un comando e restituisce il codice di uscita. Scrive tramite "out" e "err",
// così i test non devono lanciare un processo.
function esegui(argv, { env = process.env, out = console.log, err = console.error } = {}) {
  const [comando, ...resto] = argv;
  if (!comando || !OPZIONI[comando]) {
    err(USO);
    return 2;
  }
  let args;
  try {
    args = parseArgs({ args: resto, options: OPZIONI[comando], allowPositionals: false }).values;
  } catch (e) {
    err(`Errore: ${e.message}\n${USO}`);
    return 2;
  }

  const percorso = archivio.percorsoDati(env);
  const db = archivio.leggi(percorso);

  if (comando === 'laboratori') {
    for (const l of db.laboratori) out(`${l.id.padEnd(9)}  ${l.nome}  (${l.capienza} posti)`);
    return 0;
  }

  if (comando === 'elenco') {
    const righe = logica.elenco(db, {
      data: args.data,
      docenteId: args.docente,
      includiAnnullate: args.tutte,
    });
    if (righe.length === 0) out('Nessuna prenotazione.');
    for (const p of righe) out(riga(db, p));
    return 0;
  }

  if (comando === 'prenota') {
    const richiesta = {
      labId: args.lab,
      docenteId: args.docente,
      classeId: args.classe,
      data: args.data,
      inizio: args.inizio,
      fine: args.fine,
    };
    try {
      const p = logica.prenota(db, richiesta, adessoDaAmbiente(env));
      archivio.scrivi(percorso, db);
      out(`Prenotazione ${p.id} registrata.`);
      return 0;
    } catch (e) {
      if (e instanceof logica.ErroreRegola) {
        err(`RIFIUTATA (${e.codice}): ${e.message}`);
        return 1;
      }
      throw e;
    }
  }
  return 2;
}

if (require.main === module) {
  process.exitCode = esegui(process.argv.slice(2));
}

module.exports = { esegui };
