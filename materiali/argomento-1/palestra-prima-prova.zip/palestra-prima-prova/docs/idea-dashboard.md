<!-- bozza da confermare dopo la prova in AI Studio -->
# Piano della dashboard dei laboratori

Piano nato dalla demo con AI Studio. È un'idea, non una specifica: dice che cosa si vorrebbe vedere,
non come si costruisce né quali casi limite vanno gestiti. I dati sono quelli inventati di `dati/dati.json`.

## A che cosa serve

Un docente apre una pagina e vede a colpo d'occhio chi usa quale laboratorio e quando, e dove ci sono problemi.

## Le viste

1. **Settimana per laboratorio.** Una griglia con i giorni dal lunedì al venerdì e le ore dalle 08:00 alle
   18:00, una per ciascuno dei quattro laboratori. Si parte dalla settimana del 16 novembre 2026; due frecce
   portano alla settimana prima e a quella dopo.
2. **Problemi.** Un elenco, in cima alla pagina, di ciò che non va, con il laboratorio e la data:
   - classi che non entrano in un laboratorio (in questi dati, 4A-INF con 25 studenti non entra in nessuno);
   - prenotazioni che si sovrappongono;
   - prenotazioni in un giorno di chiusura.
3. **Dettaglio.** Cliccando una prenotazione si vedono classe, docente, orario e stato.

## Le regole

- **Sovrapposizione.** Due prenotazioni si sovrappongono se sono nello stesso laboratorio, nello stesso
  giorno, e gli orari si intersecano. Una che finisce alle 11:00 e una che comincia alle 11:00 **non** si
  sovrappongono (esempio nei dati: P-0003 e P-0004, il 12 novembre).
- **Annullate.** Le prenotazioni annullate si vedono barrate, ma non contano per le sovrapposizioni
  (esempio: P-0006, laboratorio Elettronica, il 17 novembre).
- **Capienza.** Una classe entra in un laboratorio se i suoi studenti non superano i posti: 24 studenti
  entrano in un laboratorio da 24 (3C-INF in LAB-INF1).
- **Chiusure.** Nei giorni di chiusura (8, 24, 25, 26 e 31 dicembre 2026) e nel fine settimana il laboratorio
  risulta chiuso e la griglia lo mostra.

## Che cosa non fa

- Non permette di prenotare né di annullare: è solo da leggere.
- Nessun accesso con nome e password.
- Nessun servizio esterno, nessuna intelligenza artificiale dentro la pagina.
- Nessun dato reale: solo i dati inventati.

## Domande ancora aperte

- Che cosa vede un docente delle prenotazioni degli altri: tutto, o solo laboratorio e orario?
- Se due prenotazioni in conflitto esistono già nei dati, si segnalano tutte e due o solo la più recente?
