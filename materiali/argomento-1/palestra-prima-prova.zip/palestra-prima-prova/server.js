'use strict';
// Server HTTP minimo, facoltativo. Ascolta solo su 127.0.0.1 (il tuo PC, nessuno da fuori).
//   node server.js        poi apri http://127.0.0.1:3000
//
//   GET  /                       pagina HTML
//   GET  /api/prenotazioni       elenco (?data=AAAA-MM-GG, ?docente=d01)
//   POST /api/prenota            corpo JSON come per la riga di comando
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const archivio = require('./src/archivio');
const logica = require('./src/logica');

function creaServer({ percorso = archivio.percorsoDati(), adesso = () => new Date() } = {}) {
  function rispondi(res, stato, corpo, tipo = 'application/json; charset=utf-8') {
    res.writeHead(stato, { 'Content-Type': tipo });
    res.end(typeof corpo === 'string' ? corpo : JSON.stringify(corpo));
  }

  function leggiCorpo(req) {
    return new Promise((resolve, reject) => {
      let testo = '';
      req.on('data', (pezzo) => {
        testo += pezzo;
        if (testo.length > 10_000) {
          reject(new Error('Corpo troppo grande'));
          req.destroy();
        }
      });
      req.on('end', () => resolve(testo));
      req.on('error', reject);
    });
  }

  return http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');
    try {
      if (req.method === 'GET' && url.pathname === '/') {
        const pagina = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
        return rispondi(res, 200, pagina, 'text/html; charset=utf-8');
      }
      if (req.method === 'GET' && url.pathname === '/api/prenotazioni') {
        const db = archivio.leggi(percorso);
        const righe = logica.elenco(db, {
          data: url.searchParams.get('data') || undefined,
          docenteId: url.searchParams.get('docente') || undefined,
        });
        return rispondi(res, 200, righe);
      }
      if (req.method === 'POST' && url.pathname === '/api/prenota') {
        let richiesta;
        try {
          richiesta = JSON.parse(await leggiCorpo(req));
        } catch {
          return rispondi(res, 400, { errore: { codice: 'JSON_NON_VALIDO', messaggio: 'Corpo non valido.' } });
        }
        const db = archivio.leggi(percorso);
        try {
          const p = logica.prenota(db, richiesta || {}, adesso());
          archivio.scrivi(percorso, db);
          return rispondi(res, 201, p);
        } catch (e) {
          if (e instanceof logica.ErroreRegola) {
            return rispondi(res, 422, { errore: { codice: e.codice, messaggio: e.message } });
          }
          throw e;
        }
      }
      return rispondi(res, 404, { errore: { codice: 'NON_TROVATO', messaggio: 'Percorso inesistente.' } });
    } catch (e) {
      return rispondi(res, 500, { errore: { codice: 'ERRORE_INTERNO', messaggio: 'Errore interno.' } });
    }
  });
}

if (require.main === module) {
  const porta = Number(process.env.PORTA) || 3000;
  creaServer().listen(porta, '127.0.0.1', () => {
    console.log(`Palestra in ascolto su http://127.0.0.1:${porta}`);
  });
}

module.exports = { creaServer };
