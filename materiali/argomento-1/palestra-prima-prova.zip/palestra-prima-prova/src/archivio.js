'use strict';
// Lettura e scrittura del file JSON con i dati. Nessun database: è una palestra.
const fs = require('node:fs');
const path = require('node:path');

function percorsoDati(env = process.env) {
  return env.PALESTRA_DATI || path.join(__dirname, '..', 'dati', 'dati.json');
}

function leggi(percorso) {
  return JSON.parse(fs.readFileSync(percorso, 'utf8'));
}

function scrivi(percorso, db) {
  fs.writeFileSync(percorso, JSON.stringify(db, null, 2) + '\n', 'utf8');
}

module.exports = { percorsoDati, leggi, scrivi };
