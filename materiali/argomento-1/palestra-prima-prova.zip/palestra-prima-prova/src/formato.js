'use strict';
// Formattazione delle righe per la riga di comando.

function riga(db, p) {
  const lab = db.laboratori.find((l) => l.id === p.labId);
  const docente = db.docenti.find((d) => d.id === p.docenteId);
  const classe = db.classi.find((c) => c.id === p.classeId);
  const stato = p.stato === 'attiva' ? '' : ` [${p.stato}]`;
  return [
    p.id.padEnd(7),
    p.data,
    `${p.inizio}-${p.fine}`,
    (lab ? lab.id : p.labId).padEnd(9),
    (classe ? classe.nome : p.classeId).padEnd(15),
    (docente ? docente.nome : p.docenteId) + stato,
  ].join('  ');
}

module.exports = { riga };
