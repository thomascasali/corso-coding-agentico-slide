'use strict';
// Logica di prenotazione dei laboratori. Funzioni sui dati in memoria:
// niente file, niente rete. Chi legge o scrive il file è src/archivio.js.

class ErroreRegola extends Error {
  constructor(codice, messaggio) {
    super(messaggio);
    this.name = 'ErroreRegola';
    this.codice = codice;
  }
}

const APERTURA = '08:00';
const CHIUSURA = '18:00';
const RE_DATA = /^\d{4}-\d{2}-\d{2}$/;
const RE_ORA = /^([01]\d|2[0-3]):[0-5]\d$/;

function dataValida(s) {
  if (typeof s !== 'string' || !RE_DATA.test(s)) return false;
  const d = new Date(s + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}

function oraValida(s) {
  return typeof s === 'string' && RE_ORA.test(s);
}

// 0 = domenica ... 6 = sabato
function giornoSettimana(data) {
  return new Date(data + 'T00:00:00Z').getUTCDay();
}

// Data e ora locali di "adesso" come stringhe confrontabili (AAAA-MM-GG, HH:MM).
function adessoComeStringhe(adesso) {
  const due = (n) => String(n).padStart(2, '0');
  return {
    data: `${adesso.getFullYear()}-${due(adesso.getMonth() + 1)}-${due(adesso.getDate())}`,
    ora: `${due(adesso.getHours())}:${due(adesso.getMinutes())}`,
  };
}

function inPassato(data, inizio, adesso) {
  const a = adessoComeStringhe(adesso);
  return data < a.data || (data === a.data && inizio < a.ora);
}

// Due prenotazioni si sovrappongono se sono nello stesso laboratorio, nello
// stesso giorno, e gli orari si intersecano.
function sovrapposti(a, b) {
  return a.labId === b.labId && a.data === b.data && a.inizio < b.fine && b.inizio < a.fine;
}

function trovaConflitti(db, richiesta) {
  return db.prenotazioni.filter((p) => p.stato === 'attiva' && sovrapposti(p, richiesta));
}

function idSuccessivo(db) {
  const massimo = db.prenotazioni.reduce((m, p) => Math.max(m, Number(p.id.slice(2))), 0);
  return 'P-' + String(massimo + 1).padStart(4, '0');
}

function controllaRichiesta(db, r, adesso) {
  const campi = ['labId', 'docenteId', 'classeId', 'data', 'inizio', 'fine'];
  for (const campo of campi) {
    if (typeof r[campo] !== 'string' || r[campo] === '') {
      throw new ErroreRegola('CAMPO_MANCANTE', `Manca il campo ${campo}.`);
    }
  }
  if (!dataValida(r.data)) throw new ErroreRegola('DATA_NON_VALIDA', `Data non valida: ${r.data}.`);
  if (!oraValida(r.inizio) || !oraValida(r.fine)) {
    throw new ErroreRegola('ORA_NON_VALIDA', 'Gli orari vanno scritti come HH:MM.');
  }
  if (r.inizio >= r.fine) {
    throw new ErroreRegola('ORARIO_INVERTITO', "L'ora di fine deve essere dopo quella di inizio.");
  }
  if (r.inizio < APERTURA || r.fine > CHIUSURA) {
    throw new ErroreRegola('FUORI_ORARIO', `I laboratori sono aperti dalle ${APERTURA} alle ${CHIUSURA}.`);
  }
  const giorno = giornoSettimana(r.data);
  if (giorno === 0 || giorno === 6) {
    throw new ErroreRegola('WEEKEND', 'Il sabato e la domenica la scuola è chiusa.');
  }
  if (db.chiusure.includes(r.data)) {
    throw new ErroreRegola('GIORNO_DI_CHIUSURA', `Il ${r.data} la scuola è chiusa.`);
  }
  if (inPassato(r.data, r.inizio, adesso)) {
    throw new ErroreRegola('NEL_PASSATO', 'Non si può prenotare nel passato.');
  }
  const lab = db.laboratori.find((l) => l.id === r.labId);
  if (!lab) throw new ErroreRegola('LAB_SCONOSCIUTO', `Laboratorio sconosciuto: ${r.labId}.`);
  if (!db.docenti.some((d) => d.id === r.docenteId)) {
    throw new ErroreRegola('DOCENTE_SCONOSCIUTO', `Docente sconosciuto: ${r.docenteId}.`);
  }
  const classe = db.classi.find((c) => c.id === r.classeId);
  if (!classe) throw new ErroreRegola('CLASSE_SCONOSCIUTA', `Classe sconosciuta: ${r.classeId}.`);
  // Capienza compresa: 24 studenti entrano in un laboratorio da 24.
  if (classe.studenti > lab.capienza) {
    throw new ErroreRegola(
      'CAPIENZA',
      `${classe.nome} ha ${classe.studenti} studenti, ${lab.nome} ne contiene ${lab.capienza}.`
    );
  }
  const conflitti = trovaConflitti(db, r);
  if (conflitti.length > 0) {
    throw new ErroreRegola('CONFLITTO', `Il laboratorio è già occupato (${conflitti[0].id}).`);
  }
}

// Aggiunge la prenotazione ai dati in memoria e la restituisce.
// Se una regola non è rispettata lancia ErroreRegola e non modifica nulla.
function prenota(db, richiesta, adesso = new Date()) {
  controllaRichiesta(db, richiesta, adesso);
  const prenotazione = {
    id: idSuccessivo(db),
    labId: richiesta.labId,
    docenteId: richiesta.docenteId,
    classeId: richiesta.classeId,
    data: richiesta.data,
    inizio: richiesta.inizio,
    fine: richiesta.fine,
    stato: 'attiva',
  };
  db.prenotazioni.push(prenotazione);
  return prenotazione;
}

// Segna come annullata la prenotazione con questo id. Nessun altro controllo:
// chi la chiama deve aver già verificato di chi è e se si può annullare.
function annulla(db, id) {
  const p = db.prenotazioni.find((x) => x.id === id);
  if (!p) throw new ErroreRegola('NON_TROVATA', `Prenotazione inesistente: ${id}.`);
  p.stato = 'annullata';
  return p;
}

// Elenco ordinato per data e ora. Filtri: data, docenteId, includiAnnullate.
function elenco(db, filtri = {}) {
  return db.prenotazioni
    .filter((p) => filtri.includiAnnullate || p.stato === 'attiva')
    .filter((p) => !filtri.data || p.data === filtri.data)
    .filter((p) => !filtri.docenteId || p.docenteId === filtri.docenteId)
    .sort((a, b) => (a.data + a.inizio + a.labId).localeCompare(b.data + b.inizio + b.labId));
}

module.exports = {
  ErroreRegola,
  APERTURA,
  CHIUSURA,
  dataValida,
  oraValida,
  giornoSettimana,
  inPassato,
  sovrapposti,
  trovaConflitti,
  prenota,
  annulla,
  elenco,
};
