'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { esegui } = require('../cli');

const ORIGINALE = path.join(__dirname, '..', 'dati', 'dati.json');

// Copia i dati in una cartella temporanea: i test non toccano mai dati/dati.json.
function ambiente() {
  const cartella = fs.mkdtempSync(path.join(os.tmpdir(), 'palestra-'));
  const file = path.join(cartella, 'dati.json');
  fs.copyFileSync(ORIGINALE, file);
  return { file, env: { PALESTRA_DATI: file, PALESTRA_ADESSO: '2026-11-09T09:00:00' } };
}

function lancia(argv, env) {
  const out = [];
  const err = [];
  const codice = esegui(argv, { env, out: (s) => out.push(s), err: (s) => err.push(s) });
  return { codice, out, err };
}

test('laboratori: stampa una riga per laboratorio', () => {
  const { env } = ambiente();
  const r = lancia(['laboratori'], env);
  assert.equal(r.codice, 0);
  assert.equal(r.out.length, 4);
});

test('elenco: mostra le prenotazioni attive', () => {
  const { env } = ambiente();
  const r = lancia(['elenco'], env);
  assert.equal(r.codice, 0);
  assert.equal(r.out.length, 7);
  assert.match(r.out[0], /^P-0001/);
});

test('elenco: --tutte include le annullate, --docente filtra', () => {
  const { env } = ambiente();
  assert.equal(lancia(['elenco', '--tutte'], env).out.length, 8);
  assert.equal(lancia(['elenco', '--docente', 'd01'], env).out.length, 2);
});

test('elenco: un\'opzione sconosciuta è un errore d\'uso', () => {
  const { env } = ambiente();
  const r = lancia(['elenco', '--colore', 'rosso'], env);
  assert.equal(r.codice, 2);
});

test('prenota: scrive nel file dei dati', () => {
  const { file, env } = ambiente();
  const r = lancia(
    ['prenota', '--lab', 'LAB-INF1', '--docente', 'd01', '--classe', '3A-INF', '--data', '2026-11-19', '--inizio', '09:00', '--fine', '11:00'],
    env
  );
  assert.equal(r.codice, 0);
  assert.match(r.out[0], /P-0009/);
  assert.equal(JSON.parse(fs.readFileSync(file, 'utf8')).prenotazioni.length, 9);
});

test('prenota: una richiesta rifiutata esce con 1 e non scrive', () => {
  const { file, env } = ambiente();
  const prima = fs.readFileSync(file, 'utf8');
  const r = lancia(
    ['prenota', '--lab', 'LAB-INF1', '--docente', 'd01', '--classe', '3A-INF', '--data', '2026-11-12', '--inizio', '10:00', '--fine', '12:00'],
    env
  );
  assert.equal(r.codice, 1);
  assert.match(r.err[0], /CONFLITTO/);
  assert.equal(fs.readFileSync(file, 'utf8'), prima);
});

test('senza comando stampa l\'uso ed esce con 2', () => {
  assert.equal(lancia([], ambiente().env).codice, 2);
});

test('lanciato come programma funziona davvero', () => {
  const { env } = ambiente();
  const testo = execFileSync(process.execPath, [path.join(__dirname, '..', 'cli.js'), 'laboratori'], {
    env: { ...process.env, ...env },
    encoding: 'utf8',
  });
  assert.match(testo, /LAB-INF1/);
});
