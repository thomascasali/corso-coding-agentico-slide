'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const logica = require('../src/logica');
const datiOriginali = require('../dati/dati.json');

// "Adesso" fisso nei test: lunedì 9 novembre 2026, ore 09:00 (ora locale).
const ADESSO = new Date(2026, 10, 9, 9, 0);

const nuovoDb = () => structuredClone(datiOriginali);

// Una richiesta valida: giovedì 19 novembre, laboratorio libero. I campi si cambiano caso per caso.
const richiesta = (cambi = {}) => ({
  labId: 'LAB-INF1',
  docenteId: 'd01',
  classeId: '3A-INF',
  data: '2026-11-19',
  inizio: '09:00',
  fine: '11:00',
  ...cambi,
});

function rifiutata(db, r, codice) {
  const prima = JSON.stringify(db);
  assert.throws(
    () => logica.prenota(db, r, ADESSO),
    (e) => e instanceof logica.ErroreRegola && e.codice === codice
  );
  assert.equal(JSON.stringify(db), prima, 'una richiesta rifiutata non deve modificare i dati');
}

test('prenota: una richiesta valida viene registrata con il primo id libero', () => {
  const db = nuovoDb();
  const p = logica.prenota(db, richiesta(), ADESSO);
  assert.equal(p.id, 'P-0009');
  assert.equal(p.stato, 'attiva');
  assert.equal(db.prenotazioni.length, 9);
});

test('conflitti: orari che si intersecano sono rifiutati', () => {
  // P-0003 occupa LAB-INF1 il 12/11 dalle 09:00 alle 11:00
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-12', inizio: '10:00', fine: '12:00' }), 'CONFLITTO');
});

test('conflitti: una richiesta dentro una prenotazione esistente è rifiutata', () => {
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-12', inizio: '09:30', fine: '10:00' }), 'CONFLITTO');
});

test('conflitti: una richiesta che ne contiene un\'altra è rifiutata', () => {
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-12', inizio: '08:00', fine: '14:00' }), 'CONFLITTO');
});

test('conflitti: una prenotazione che inizia quando un\'altra finisce è accettata', () => {
  // P-0004 finisce alle 13:00
  const p = logica.prenota(nuovoDb(), richiesta({ data: '2026-11-12', inizio: '13:00', fine: '14:00' }), ADESSO);
  assert.equal(p.inizio, '13:00');
});

test('conflitti: una prenotazione che finisce quando un\'altra inizia è accettata', () => {
  // P-0003 inizia alle 09:00
  const p = logica.prenota(nuovoDb(), richiesta({ data: '2026-11-12', inizio: '08:00', fine: '09:00' }), ADESSO);
  assert.equal(p.fine, '09:00');
});

test('conflitti: lo stesso orario in un altro laboratorio è accettato', () => {
  const r = richiesta({ labId: 'LAB-RETI', classeId: '3B-ELE', data: '2026-11-12', inizio: '09:00', fine: '11:00' });
  assert.equal(logica.prenota(nuovoDb(), r, ADESSO).labId, 'LAB-RETI');
});

test('conflitti: una prenotazione annullata non blocca il laboratorio', () => {
  // P-0006 (annullata) occupava LAB-ELET il 17/11 dalle 08:00 alle 10:00
  const r = richiesta({ labId: 'LAB-ELET', classeId: '3B-ELE', docenteId: 'd04', data: '2026-11-17', inizio: '08:00', fine: '10:00' });
  assert.equal(logica.prenota(nuovoDb(), r, ADESSO).labId, 'LAB-ELET');
});

test('passato: una data già trascorsa è rifiutata', () => {
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-06' }), 'NEL_PASSATO');
});

test('passato: oggi, ma con inizio già trascorso, è rifiutato', () => {
  rifiutata(nuovoDb(), richiesta({ labId: 'LAB-RETI', classeId: '3B-ELE', data: '2026-11-09', inizio: '08:00', fine: '09:00' }), 'NEL_PASSATO');
});

test('passato: oggi, con inizio esattamente adesso, è accettato', () => {
  const r = richiesta({ labId: 'LAB-RETI', classeId: '3B-ELE', data: '2026-11-09', inizio: '09:00', fine: '10:00' });
  assert.equal(logica.prenota(nuovoDb(), r, ADESSO).data, '2026-11-09');
});

test('orario: fuori dall\'apertura è rifiutato', () => {
  rifiutata(nuovoDb(), richiesta({ inizio: '06:00', fine: '07:00' }), 'FUORI_ORARIO');
  rifiutata(nuovoDb(), richiesta({ inizio: '17:00', fine: '20:00' }), 'FUORI_ORARIO');
});

test('orario: fine prima dell\'inizio è rifiutata', () => {
  rifiutata(nuovoDb(), richiesta({ inizio: '11:00', fine: '09:00' }), 'ORARIO_INVERTITO');
  rifiutata(nuovoDb(), richiesta({ inizio: '11:00', fine: '11:00' }), 'ORARIO_INVERTITO');
});

test('giorni: sabato, domenica e giorni di chiusura sono rifiutati', () => {
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-14' }), 'WEEKEND');
  rifiutata(nuovoDb(), richiesta({ data: '2026-11-15' }), 'WEEKEND');
  rifiutata(nuovoDb(), richiesta({ data: '2026-12-08' }), 'GIORNO_DI_CHIUSURA');
});

test('capienza: una classe più numerosa del laboratorio è rifiutata', () => {
  rifiutata(nuovoDb(), richiesta({ classeId: '4A-INF' }), 'CAPIENZA'); // 25 studenti, 24 posti
  rifiutata(nuovoDb(), richiesta({ labId: 'LAB-INF2', classeId: '3C-INF' }), 'CAPIENZA'); // 24 studenti, 20 posti
});

test('capienza: una classe che riempie esattamente il laboratorio è accettata', () => {
  const p = logica.prenota(nuovoDb(), richiesta({ classeId: '3C-INF' }), ADESSO); // 24 studenti, 24 posti
  assert.equal(p.classeId, '3C-INF');
});

test('campi: valori mancanti o malformati sono rifiutati', () => {
  rifiutata(nuovoDb(), richiesta({ labId: undefined }), 'CAMPO_MANCANTE');
  rifiutata(nuovoDb(), richiesta({ docenteId: '' }), 'CAMPO_MANCANTE');
  rifiutata(nuovoDb(), richiesta({ data: '2026-02-30' }), 'DATA_NON_VALIDA');
  rifiutata(nuovoDb(), richiesta({ data: '19/11/2026' }), 'DATA_NON_VALIDA');
  rifiutata(nuovoDb(), richiesta({ inizio: '9:00' }), 'ORA_NON_VALIDA');
});

test('riferimenti: laboratorio, docente e classe devono esistere', () => {
  rifiutata(nuovoDb(), richiesta({ labId: 'LAB-XXX' }), 'LAB_SCONOSCIUTO');
  rifiutata(nuovoDb(), richiesta({ docenteId: 'd99' }), 'DOCENTE_SCONOSCIUTO');
  rifiutata(nuovoDb(), richiesta({ classeId: '9Z-XXX' }), 'CLASSE_SCONOSCIUTA');
});

test('annulla: segna la prenotazione come annullata', () => {
  const db = nuovoDb();
  assert.equal(logica.annulla(db, 'P-0003').stato, 'annullata');
  assert.equal(db.prenotazioni.find((p) => p.id === 'P-0003').stato, 'annullata');
});

test('annulla: un id inesistente è un errore', () => {
  assert.throws(() => logica.annulla(nuovoDb(), 'P-9999'), (e) => e.codice === 'NON_TROVATA');
});

test('elenco: ordinato per data e ora, senza le annullate', () => {
  const ids = logica.elenco(nuovoDb()).map((p) => p.id);
  assert.deepEqual(ids, ['P-0001', 'P-0002', 'P-0003', 'P-0004', 'P-0005', 'P-0007', 'P-0008']);
});

test('elenco: con includiAnnullate le mostra', () => {
  assert.equal(logica.elenco(nuovoDb(), { includiAnnullate: true }).length, 8);
});

test('elenco: filtro per docente e per data', () => {
  const db = nuovoDb();
  assert.deepEqual(logica.elenco(db, { docenteId: 'd01' }).map((p) => p.id), ['P-0001', 'P-0003']);
  assert.deepEqual(logica.elenco(db, { data: '2026-11-12' }).map((p) => p.id), ['P-0003', 'P-0004']);
});

test('date: validazione e giorno della settimana', () => {
  assert.equal(logica.dataValida('2026-11-09'), true);
  assert.equal(logica.dataValida('2026-13-01'), false);
  assert.equal(logica.dataValida('2026-2-1'), false);
  assert.equal(logica.giornoSettimana('2026-11-09'), 1); // lunedì
  assert.equal(logica.giornoSettimana('2026-11-15'), 0); // domenica
});
