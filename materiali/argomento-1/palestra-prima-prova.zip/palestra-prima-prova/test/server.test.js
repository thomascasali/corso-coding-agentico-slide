'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { creaServer } = require('../server');

async function conServer(prova) {
  const cartella = fs.mkdtempSync(path.join(os.tmpdir(), 'palestra-srv-'));
  const file = path.join(cartella, 'dati.json');
  fs.copyFileSync(path.join(__dirname, '..', 'dati', 'dati.json'), file);
  const server = creaServer({ percorso: file, adesso: () => new Date(2026, 10, 9, 9, 0) });
  await new Promise((ok) => server.listen(0, '127.0.0.1', ok));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await prova(base);
  } finally {
    await new Promise((ok) => server.close(ok));
  }
}

test('GET /api/prenotazioni restituisce le prenotazioni attive', () =>
  conServer(async (base) => {
    const righe = await (await fetch(base + '/api/prenotazioni')).json();
    assert.equal(righe.length, 7);
  }));

test('POST /api/prenota: 201 se valida, 422 se una regola non è rispettata', () =>
  conServer(async (base) => {
    const valida = { labId: 'LAB-INF1', docenteId: 'd01', classeId: '3A-INF', data: '2026-11-19', inizio: '09:00', fine: '11:00' };
    const ok = await fetch(base + '/api/prenota', { method: 'POST', body: JSON.stringify(valida) });
    assert.equal(ok.status, 201);
    const doppia = await fetch(base + '/api/prenota', { method: 'POST', body: JSON.stringify(valida) });
    assert.equal(doppia.status, 422);
    assert.equal((await doppia.json()).errore.codice, 'CONFLITTO');
  }));

test('GET / serve la pagina HTML e un percorso sconosciuto dà 404', () =>
  conServer(async (base) => {
    const pagina = await fetch(base + '/');
    assert.equal(pagina.status, 200);
    assert.match(await pagina.text(), /<title>/);
    assert.equal((await fetch(base + '/non-esiste')).status, 404);
  }));
