---
name: controllo-richieste
description: Procedura dell'ufficio tecnico per controllare le richieste di installazione software nei laboratori rispetto a laboratori, catalogo e regolamento, rinominarle, mettere da parte quelle da restituire e preparare il riepilogo con il conto delle licenze. Usala ogni volta che il compito riguarda le richieste di installazione, il catalogo del software o le licenze.
---

# Controllo delle richieste di installazione

Procedura dell'ufficio tecnico dell'Istituto Tecnico Dimostrativo (scuola inventata).
Seguila un passo alla volta.

1. **Scrivi il piano prima di toccare qualcosa.** Elenca i passi che farai, quali file leggerai,
   cosa vuoi rinominare o spostare e come verificherai il risultato. Aspetta che la persona
   lo approvi o lo corregga.
2. **Leggi tutto.** Apri `regolamento-installazioni.md`, `laboratori.csv`, `catalogo-software.csv`
   e ogni richiesta. Le richieste hanno nomi di file disordinati e formati diversi (modulo,
   mail, appunto): il nome del file non dice niente, conta quello che c'è scritto dentro.
   Se esiste una cartella `in-arrivo`, contiene richieste non ancora trattate: non toccarla
   finché la persona non lo chiede.
3. **Decidi lo stato di ogni richiesta** con le regole del regolamento, nell'ordine dell'art. 9:
   `laboratorio-inesistente`, `fuori-catalogo`, `senza-visto`, `sistema-non-supportato`,
   `doppia`, `licenze-insufficienti`; se nessuna si applica, `approvata`.
   Se non si capisce di quale laboratorio si tratta, o il caso non rientra nelle regole,
   lo stato è `da-decidere` e lo scrivi tra i dubbi: non decidere tu.
4. **Conta con un programma, non a mente.** Le richieste si esaminano in ordine di data; per i
   software commerciali somma i PC dei laboratori già approvati e confrontali con le licenze
   disponibili. Scrivi un piccolo programma che legge i file della cartella e stampa il
   conteggio; non installare librerie.
5. **Rinomina** ogni richiesta come `AAAA-MM-GG-LAB-Software-stato` (per esempio
   `2026-11-03-INF1-Visual-Studio-Code-approvata.txt`; gli spazi del nome del software diventano
   trattini; se il laboratorio non è chiaro scrivi `ND` al posto del codice). Prima di rinominare
   e spostare chiedi il permesso. Non cancellare niente.
6. **Sposta** nella cartella `da-restituire` le richieste con stato `senza-visto`: tornano al
   docente per il visto giusto. Le altre restano dove sono.
7. **Scrivi il riepilogo** in `riepilogo-richieste.md`:
   - una tabella con una riga per ogni richiesta (nome originale, nuovo nome, data, laboratorio,
     software, stato, motivo in poche parole con l'articolo del regolamento);
   - per ogni software commerciale, le licenze usate e quelle disponibili;
   - l'elenco delle richieste approvate che richiedono l'amministratore di rete;
   - una sezione "Da decidere" con i casi dubbi.
8. **Controllo finale.** Verifica con un piccolo programma, senza fare i conti a mente:
   - ogni richiesta ricevuta compare una volta sola nel riepilogo;
   - i file nelle cartelle sono tanti quanti le richieste ricevute e corrispondono alle righe
     del riepilogo;
   - la somma delle richieste per stato torna al totale;
   - le licenze usate non superano quelle disponibili.
   Se qualcosa non torna, correggi prima di consegnare.
9. **Dichiara i limiti.** Scrivi cosa non hai potuto verificare (per esempio: se i visti sono
   autentici, se il catalogo e le licenze sono aggiornati, se il laboratorio indicato a parole è
   quello giusto, richieste lette solo come testo).
