# Regolamento per le richieste di installazione software nei laboratori

Istituto Tecnico Dimostrativo (scuola inventata). Testo di prova per l'esercitazione: nessuna regola è quella di una scuola vera.

## Art. 1 - Chi chiede e come
1. Ogni richiesta riguarda un solo software e un solo laboratorio. Chi ha bisogno dello stesso software in due laboratori presenta due richieste.
2. La richiesta contiene: docente, laboratorio, software, data e visto del responsabile del laboratorio. Può arrivare su modulo, per mail o come appunto trascritto.

## Art. 2 - Laboratorio
1. Il laboratorio deve essere uno di quelli elencati in `laboratori.csv`. Altrimenti lo stato è `laboratorio-inesistente`.
2. Se dal testo non si capisce quale laboratorio è (per esempio «il laboratorio di informatica» quando ce ne sono due), la richiesta non si decide: stato `da-decidere`, la scelta spetta a una persona.

## Art. 3 - Catalogo
1. Si installa solo software presente in `catalogo-software.csv`. Altrimenti lo stato è `fuori-catalogo`: la richiesta va alla commissione tecnica e non si installa niente.

## Art. 4 - Visto
1. Il visto deve essere del responsabile del laboratorio indicato in `laboratori.csv`.
2. Un visto mancante, vuoto o di un'altra persona non vale: stato `senza-visto`.

## Art. 5 - Sistema operativo
1. Il software deve supportare il sistema del laboratorio (colonna `sistemi` del catalogo contro colonna `sistema` di `laboratori.csv`). Altrimenti lo stato è `sistema-non-supportato`.

## Art. 6 - Richieste doppie
1. Una richiesta con stesso software e stesso laboratorio di una richiesta precedente già approvata è `doppia`. La prima per data vale, le altre no.
2. Una richiesta non approvata non rende doppia quella che la ripete.

## Art. 7 - Licenze
1. Per il software commerciale (colonna `licenze` con un numero) serve una licenza per ogni PC del laboratorio.
2. Le richieste si esaminano in ordine di data. Una richiesta è accettata solo se le licenze già assegnate più i PC del suo laboratorio non superano le licenze disponibili. Altrimenti lo stato è `licenze-insufficienti`.
3. Una richiesta respinta non consuma licenze.

## Art. 8 - Amministratore
1. Se nel catalogo `serve_admin` è `si`, l'installazione la fa l'amministratore di rete. La richiesta approvata va nell'elenco per l'amministratore.

## Art. 9 - Ordine dei controlli
1. Si assegna il primo stato che si applica, in quest'ordine: laboratorio (art. 2), catalogo (art. 3), visto (art. 4), sistema (art. 5), richiesta doppia (art. 6), licenze (art. 7). Se nessuno si applica, lo stato è `approvata`.

## Art. 10 - Casi non previsti
1. Un caso che il regolamento non prevede si segnala alla persona responsabile dell'ufficio tecnico, che decide. Non lo decide chi controlla.
