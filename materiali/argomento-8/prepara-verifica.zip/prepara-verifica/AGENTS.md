# Cartella delle verifiche: Sistemi e reti, classe 3A

Dati inventati a scopo didattico: classe, programma e verifiche non esistono.

- `programma/`: le unità di apprendimento (UdA) con gli obiettivi numerati (O1, O2, …).
- `verifiche/`: le verifiche già fatte, una per file, con la correzione in un file a parte.
- `appunti-verifiche-passate.md`: che cosa è andato storto le volte scorse.

Le verifiche nuove si salvano in `verifiche/`. Il file della verifica è quello che si stampa per gli
studenti.

Per leggere documenti Word o PDF c'è MarkItDown: `uvx markitdown <file>`.
