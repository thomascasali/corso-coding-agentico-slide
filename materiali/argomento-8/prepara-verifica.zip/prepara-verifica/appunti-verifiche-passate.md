# Appunti: che cosa è andato storto con le verifiche passate

Dati inventati a scopo didattico. Appunti di un docente, scritti di volta in volta.

- **Ottobre, verifica UdA 1 versione B.** Il totale faceva 11 punti: un esercizio da 3 invece che da 2.
  Me ne sono accorto in classe, alla terza domanda di uno studente.
- **Novembre, recupero.** Ho stampato il file con le risposte in fondo: le avevo scritte lì per comodità.
  Ristampato tutto, venti minuti persi.
- **Anno scorso, UdA 2.** In un esercizio c'era un indirizzo copiato dalla rete del laboratorio. Da allora
  solo indirizzi riservati alla documentazione: 192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24.
- **Anno scorso, UdA 2, versioni A e B.** La B aveva numeri più tondi (/24 invece di /26): era più facile.
  Le due versioni devono avere gli stessi esercizi, con numeri diversi ma della stessa difficoltà.
- **Sempre.** Un esercizio che non corrisponde a nessun obiettivo del programma è difficile da giustificare
  ai genitori. Ogni esercizio porta tra parentesi quadre l'obiettivo che verifica, per esempio [O3].
- **Formato.** Cinque esercizi da 2 punti, totale 10; intestazione con classe, nome e data; griglia in fondo.
  La correzione sta in un file a parte, con lo stesso nome e `-correzione` in fondo.
