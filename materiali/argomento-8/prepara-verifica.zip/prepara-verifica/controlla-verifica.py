#!/usr/bin/env python3
"""Controlla una verifica in due versioni (A e B) contro le regole della cartella.

Uso: python controlla-verifica.py verifiche/verifica-uda2-A.md verifiche/verifica-uda2-B.md

Controlla, per ogni versione: cinque esercizi, totale 10 punti, un obiettivo [On] per esercizio,
indirizzi IP solo dai blocchi di documentazione, nessuna risposta nel file per gli studenti, file di
correzione presente. Tra le due versioni: stessi obiettivi nello stesso ordine, stessa difficoltà
delle maschere (una /24 al posto di una /26 rende la versione più facile).
Esce con 0 se tutto è a posto, con 1 se c'è almeno un errore. Dati inventati a scopo didattico.
"""
import ipaddress
import os
import re
import sys

DOC = [ipaddress.ip_network(n) for n in ("192.0.2.0/24", "198.51.100.0/24", "203.0.113.0/24")]
TITOLO = re.compile(r"^##\s+Esercizio\s+(\d+)\s*(\[O\d+\])?\s*\((\d+)\s+punt[oi]\)", re.M)
IP = re.compile(r"(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2}))?(?!\d|\.\d)")
PREFISSO = re.compile(r"/(\d{1,2})\b")
RISPOSTE = re.compile(r"\b(soluzion[ei]|risposta\s*:|correzione)", re.I)

errori = []


def errore(msg):
    errori.append(msg)
    print("ERRORE", msg)


def esercizi(testo):
    """Lista di (numero, obiettivo, punti, testo dell'esercizio)."""
    trovati = list(TITOLO.finditer(testo))
    out = []
    for i, m in enumerate(trovati):
        fine = trovati[i + 1].start() if i + 1 < len(trovati) else len(testo)
        out.append((int(m.group(1)), m.group(2), int(m.group(3)), testo[m.end():fine]))
    return out


def controlla_versione(percorso):
    nome = os.path.basename(percorso)
    if not os.path.isfile(percorso):
        errore(nome + ": il file non esiste")
        return None
    testo = open(percorso, encoding="utf-8").read()
    es = esercizi(testo)
    if len(es) != 5:
        errore("%s: %d esercizi invece di 5" % (nome, len(es)))
    totale = sum(e[2] for e in es)
    if totale != 10:
        errore("%s: il totale fa %d punti invece di 10" % (nome, totale))
    for n, ob, _, _ in es:
        if not ob:
            errore("%s: l'esercizio %d non dice quale obiettivo verifica ([On] nel titolo)" % (nome, n))
    for ip, _ in IP.findall(testo):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        if ip.startswith("255.") or ip == "0.0.0.0":
            continue  # una maschera, non un indirizzo
        if not any(a in rete for rete in DOC):
            errore("%s: l'indirizzo %s non è nei blocchi di documentazione" % (nome, ip))
    if RISPOSTE.search(testo):
        errore("%s: nel file per gli studenti c'è una parola da correzione (%s)" % (nome, RISPOSTE.search(testo).group(0)))
    corr = percorso[:-3] + "-correzione.md"
    if not os.path.isfile(corr):
        errore("%s: manca il file di correzione %s" % (nome, os.path.basename(corr)))
    else:
        punti = re.findall(r"^\s*(\d+)\.", open(corr, encoding="utf-8").read(), re.M)
        if len(set(punti)) < len(es):
            errore("%s: la correzione ha %d risposte numerate per %d esercizi" % (os.path.basename(corr), len(set(punti)), len(es)))
    print("controllato", nome, "-", len(es), "esercizi,", totale, "punti")
    return es


def tonde(blocco):
    """Quante maschere «tonde» (/8, /16, /24) usa un esercizio."""
    return sum(1 for p in PREFISSO.findall(blocco) if int(p) % 8 == 0)


def main(argv):
    if len(argv) != 2:
        sys.exit(__doc__)
    a, b = (controlla_versione(p) for p in argv)
    if a and b:
        if [e[1] for e in a] != [e[1] for e in b]:
            errore("le versioni A e B non verificano gli stessi obiettivi nello stesso ordine")
        for ea, eb in zip(a, b):
            if tonde(ea[3]) != tonde(eb[3]):
                errore("esercizio %d: le due versioni non hanno maschere della stessa difficoltà" % ea[0])
    print("TUTTO OK" if not errori else "%d errori" % len(errori))
    return 0 if not errori else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
