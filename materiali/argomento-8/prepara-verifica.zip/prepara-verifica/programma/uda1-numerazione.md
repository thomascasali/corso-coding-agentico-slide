# UdA 1: sistemi di numerazione (classe 3A, Sistemi e reti)

Dati inventati a scopo didattico.

## Obiettivi

- **O1** Convertire un numero da decimale a binario e viceversa.
- **O2** Convertire un numero da binario a esadecimale e viceversa.
- **O3** Sommare due numeri binari di otto bit e riconoscere il riporto.
- **O4** Dire quanti valori si rappresentano con n bit.
