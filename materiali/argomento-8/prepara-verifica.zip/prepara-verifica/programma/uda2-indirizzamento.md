# UdA 2: indirizzamento IPv4 (classe 3A, Sistemi e reti)

Dati inventati a scopo didattico.

## Obiettivi

- **O1** Scrivere un indirizzo IPv4 in binario e in notazione decimale puntata, e viceversa.
- **O2** Leggere una maschera in notazione CIDR (/24, /26, /27) e scriverla in decimale puntato.
- **O3** Calcolare indirizzo di rete e indirizzo di broadcast di una rete.
- **O4** Calcolare quanti host si possono indirizzare in una rete.
- **O5** Dire se due host stanno nella stessa rete, motivando con il calcolo.

## Ore e materiali

Dieci ore in classe, due in laboratorio (simulatore di rete). Libro di testo, capitolo 4.
Esercizi svolti in classe: conversioni binario-decimale, maschere /24 e /26, un caso di due PC che
non si vedono perché le maschere sono diverse.
