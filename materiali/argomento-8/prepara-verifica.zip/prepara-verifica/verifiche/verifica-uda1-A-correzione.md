# Correzione: verifica UdA 1, versione A

Per il docente: non si stampa per gli studenti.

1. 77 = 1001101 (64 + 8 + 4 + 1).
2. 10110110 = 182 (128 + 32 + 16 + 4 + 2).
3. 1110 1001 = E9.
4. 01101101 + 00110110 = 10100011 (109 + 54 = 163). Nessun riporto oltre l'ottavo bit.
5. 2⁶ = 64 valori: ogni bit raddoppia le combinazioni.

Mezzo punto in meno per ogni passaggio mancante; esercizio a metà se il risultato è giusto ma senza
passaggi.
