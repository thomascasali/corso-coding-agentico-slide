# Verifica di Sistemi e reti: UdA 1, sistemi di numerazione (versione A)

Classe 3A · Nome e cognome: ______________________ · Data: __________

Tempo a disposizione: un'ora. Punteggio totale: 10 punti. Scrivi i passaggi: senza passaggi
l'esercizio vale la metà.

## Esercizio 1 [O1] (2 punti)

Converti in binario il numero decimale 77.

## Esercizio 2 [O1] (2 punti)

Converti in decimale il numero binario 10110110.

## Esercizio 3 [O2] (2 punti)

Converti in esadecimale il numero binario 11101001.

## Esercizio 4 [O3] (2 punti)

Somma i numeri binari 01101101 e 00110110. C'è un riporto oltre l'ottavo bit?

## Esercizio 5 [O4] (2 punti)

Quanti valori diversi si possono rappresentare con 6 bit? Spiega perché.

## Griglia

| Esercizio | Punti | Ottenuti |
|---|---|---|
| 1 | 2 | |
| 2 | 2 | |
| 3 | 2 | |
| 4 | 2 | |
| 5 | 2 | |
| Totale | 10 | |
